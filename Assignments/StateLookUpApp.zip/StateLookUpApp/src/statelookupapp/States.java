/*
class of object to describe a State 
for CSCI 111 
last edited January 21th 9:12pm
@author Abraham Schultz
 */
package statelookupapp;

public class States {

    //declare variables to describe state class 
    private String name;
    private String capitol;
    private int population;

    //create constructors********************************************************
    public States() {
        name = "";
        capitol = "";
        population = 0;
    }//end States constuctor

    public States(String Name, String Capitol, int Population) {
        this.name = Name;
        this.capitol = Capitol;
        this.population = Population;
    }//end States constructor

    // create accsesors *************************************************************
    public String getStateName() {
        return name;
    }// end getStateName

    public String getStateCapital() {
        return capitol;
    }// end getStateCapital

    public int getStatePop() {
        return population;
    }//end getStatePop

    //create mutators********************************************************************
    public void setStateName(String newName) {
        name = newName;
    }// end setStateName

    public void setStateCapitol(String newCapitol) {

        capitol = newCapitol;
    }//endStateCapitol

    public void setStatePopulation(int newPop) {
        population = newPop;
    }//endStatePopulation
//create toString method**************************************************************
    //method to print out state data
    public String toString() {
        String info;// variable to hold state information as strings
        info = "Name: " + name + ", Capital: " + capitol + ", Population:  " + population;
        return info;
    }// end toString

} // end class States

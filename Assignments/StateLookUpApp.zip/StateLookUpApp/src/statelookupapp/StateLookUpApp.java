/*
*Application for looking up States, using methods from multiple class files
*for CSCI 111 
*last edited January 21th 9:12pm
@author Abraham Schultz
 */
package statelookupapp;

import java.io.FileNotFoundException;
import javax.swing.JOptionPane;

public class StateLookUpApp {

    public static void main(String[] args) {

        // variables 
        String inName = null; // name of state user enters
        States targetState;// variable to hold instance of target State 
        StatesArray list1 = new StatesArray();// create list for states

        try {    // trys to load array from file, if cant then error message shows

            list1.loadArray("statedata.txt");

        } catch (FileNotFoundException e) {

            JOptionPane.showMessageDialog(null, "The file containing State data could"
                    + " not be retrieved ", "FILE NOT FOUND ERROR", JOptionPane.ERROR_MESSAGE);
        }// end try catch
        
        list1.printList();      // print entire array
        
                       // ask user for target state to look up
            inName = JOptionPane.showInputDialog(null, "Hello! Please enter the "
                    + "name of the State you would like to look up", "Enter State Name:", JOptionPane.QUESTION_MESSAGE);

     
        try {
            targetState = list1.findState(inName);
            if (targetState != null) {
                JOptionPane.showMessageDialog(null, targetState.toString(),
                        "State Information", JOptionPane.INFORMATION_MESSAGE);

            }//end if 
        } catch (NullPointerException e) {

            JOptionPane.showMessageDialog(null, "User Cancled Application",
                    "NULL POINTER ERROR", JOptionPane.ERROR_MESSAGE);

        }//end Try catch
    } // end main method
}// end stateLookUpApp

/*
 class of object to describe an array to hold State objects
*for CSCI 111 
*last edited January 21th 9:12pm
@author Abraham Schultz
 */
package statelookupapp;

import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class StatesArray {

    //declare variables
    private States[] states = new States[100];// create array with space for 100 objects
    private int count = 0;// number of states in list 

    // constructor*************************************************************
    StatesArray() {

    }// end StatesArray constructor

    //Accessors ****************************************************************
    public String getName(int listNumber) {
        return this.states[listNumber].getStateName();
    }//end getName

    public String getCapital(int listNumber) {
        return this.states[listNumber].getStateCapital();
    }//end getCapital

    public int getPopulation(int listNumber) {
        return this.states[listNumber].getStatePop();
    }//end getPopulation

    //Utility Methods ******************************************************************
    //method thats load array from selected data file.
    public void loadArray(String filename) throws FileNotFoundException {

        java.io.File statesFile = new java.io.File(filename);// instansiate a file object
        // temperary variables to hold input from file
        String inName;
        String inCapitol;
        int inPop;
        int counter;

        // Create a Scanner named infile to read the input stream from the file
        Scanner infile = new Scanner(statesFile);
        // for loop terminating variable is not tied to the counter variable
        for (counter = 0; infile.hasNext(); counter++) {
            // read data from the file into temporary variables
            // read Strings directly parse the integer
            inName = infile.nextLine();
            inCapitol = infile.nextLine();
            inPop = Integer.parseInt(infile.nextLine());
            // a new state is made with the temporary variables passed as arguments
            states[counter] = new States(inName, inCapitol, inPop);
            count++;
        }//end for
    }// end loadArray
//*******************************************************************************
    //method to print out list of states and information.
    public void printList() {
        int counter;// counter to represent index values in array
        for (counter = 0; counter < count; counter++) {
            System.out.println(states[counter].toString());
        }//end for
    }// end printList
//*******************************************************************************
    //method to add new states to list
    public void addState(States newState) {
        int counter;// counter for index values in array

        // looks through array until it finds an empty index spot then assigns new state 
        for (counter = 0; counter < states.length; counter++) {

            if (states[counter] == null) {// if list item is empty make item new state
                states[counter] = newState;
            }//end if
        }//end for
        count++; 
    }//end addState
//**********************************************************************************
    //method to find states in list
    public States findState(String targetState) {
        int counter;// counter for index values in array
        for (counter = 0; counter < this.getCount(); counter++) {// loop searchs through array for target state
            if (targetState.equalsIgnoreCase(states[counter].getStateName())) {
                return states[counter];
            }//end if
        }//end for
        JOptionPane.showMessageDialog(null, "State not found", "STATE NOT FOUND ERROR", JOptionPane.ERROR_MESSAGE);
        return null;
    }// end findState
//**********************************************************************************************************
    //method to get number of states in list
    public int getCount() {
        return count;
    }// end getCount

}// end statesArray

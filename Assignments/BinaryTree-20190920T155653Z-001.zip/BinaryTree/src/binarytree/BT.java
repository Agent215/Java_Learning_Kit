/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package binarytree;


public class BT {
    
     /*
        
       
        preorder -- iterate ( list all  nodes in order according to the preorder traversal of the tree)

        
        inorder -- iterate ( list all  nodes in order according to the inorder traversal of the tree)

        
        postorder -- iterate ( list all  nodes in order according to the postorder traversal of the tree)

        
        search -- given a key value, tell us whether or not the integer is in the tree.

        
        max -- return the maximum value in the tree

        
        min  -- return the minimum value in the tree
        */
    
}// end Class BT

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package binarytree;

public class Node {

    int data;           // variable to hold data, in this case an integer, in the tree
    Node leftChild;     //pointer for the left child of a Node
    Node rightChild;    // pinter for the rightChild of the Node in the binary Treee

    // null constructor
    public void Node() {
        leftChild = null;
        rightChild = null;
    }// end Node
}// end Node

/*statelookup.java
*Console I/O dialog for looking up state capitals
*for CSCI 111 
*last edited october 17th  5:04pm
@author Abraham Schultz
 */
package arrayassignment;

import java.io.File;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class ArrayAssignment {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {// main method()

        String[] states = new String[50];// declare array for state names
        String[] capitals = new String[50];// declare array for state capitals
        String targetState;// variable to hold String value of target State
        int i = 0;//counter for loop intialized at 0

// Create a File class object x and give it the name of the file to read
        File x = new File("F:\\CSI11\\capitals.txt");
        // Create a Scanner named y to read the input stream from the file x 
        Scanner y = new Scanner(x);
// loop that sorts states and capitals in to correct arrays
        while (y.hasNext()) {// Read a line of text from the file 

            states[i] = y.nextLine();
            capitals[i] = y.nextLine();
            i++;
        }
        y.close();// Close the input data stream and associated file 

        // ask user for a state name
        targetState = JOptionPane.showInputDialog(null, "Please enter the name of"
                + " a state: ", "State Name", JOptionPane.QUESTION_MESSAGE);
        System.out.println("reading from the data file...\n");
        findsate(targetState, states, capitals);
//call method to search array for state/ print if there is no state with name
    }
//*******************************************************************************************

    //method for searching array for mathcing state and printing message
    public static void findsate(String targetState, String[] state, String[] capital) throws Exception {

        boolean found = false; // true if the target state is found in the array
        int n;// loop counter
        for (n = 0; (!found) && (n < state.length); n++) {// for loop, for false and under 50
            if (targetState.matches(state[n])) {
                // if target state matches current array item then found = true
                JOptionPane.showMessageDialog(null, targetState + "'s state capital is " + capital[n]);
                found = true; //print found message and set found to true
            }// end if
        }
        // after the loop – if state entered not(found) print not found message 
        if (!found) {
            JOptionPane.showMessageDialog(null, targetState + " is not a state in"
                    + " The Unites States of America.\n", "invalid entry", JOptionPane.ERROR_MESSAGE);
        }

    }
//*****************************************************************************************************************
}

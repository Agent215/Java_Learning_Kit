/*password program
*Console I/O dialog for gettting secure password
*for CSCI 111 
*last edited october 25th  9:23pm
@author Abraham Schultz
 */
package password;

import java.util.Scanner;

public class Password {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String Password;
        String Confirm;
        do {
            Password = enterPassword();// call method to enter password
            Confirm = confirmPassword(Password); //call method to confirm password
        } while (!Password.equals(Confirm));
        // loop repeats until password entries match

        Boolean Condition = isValid(Password); // once entries match, program checks password against paramaters 
        // condition is true if password is valid . program will skip lines 29-42  if correct. otherwise it  continues until correct

        while (!Condition) { // this loop continues to ask for a new password if there is an error detected
            System.out.println("The password entered is not valid!");
             do {
                /*
       * Another loop within the error checking loop. This makes sure password entries 
       * match in the event that on the first attempt entries DID match but password was NOT VALID, 
       * this ensures that on the second attempt entries are not checked for validity until they
         match.
                 */
            Password = enterPassword();// call method to enter password
            Confirm = confirmPassword(Password); //call method to confirm password
        } while (!Password.equals(Confirm));// if entries match then check password against paramaters
            Condition = isValid(Password); // condition is true if password is valid
        }
        System.out.println("You have entered a good password!!");
    }

    //***********************************************************************
    public static String enterPassword() // method for entering password
    {
        String password;// declare password variable
        Scanner input = new Scanner(System.in);//scanner object within method declared
        System.out.println("Please enter the password : ");//asks for password
        password = input.nextLine();// next input types = password
        return password; //return password to main as String
    }

    //*****************************************************************************
    public static boolean isValid(String password) { // method for checking if password is valid
        /*
        This method checks each of the paramaters agaisnt the entered password. 
        if all variables are entered correctly then all booleans will return
        true. it uses a for loop that iterates through each letter 
        of the password until reaching the last letter.
         */
        //booleans and variables needed to describe each of the paramaters for password
        boolean length = true;
        boolean digit = false;
        boolean letter = false;
        boolean nonnumeric = false;
        boolean spaces = true;
        boolean exclamation = true;
        boolean repeating = true;
        String[] characters = password.split(""); // here each letter of the password is put in to a string array called characters
        String[] symbols = {"!", "#", "@", "$", "%", "^", "&", "*", "(", " )", "- ", "_",
            "=", "+", "[", "]", ";", ":", "'", ",", "<", ".", ">", "/", "?"};
        // string array to use for nonnumeric symbols comparison
        if (password.length() < 8) {// if password is to short then boolean length = false
            length = false;
            System.out.println("Password is to short. The password should be at least 8 characters long.");
            // tells user that the password is to short
        }
        for (int i = 0; i < password.length(); i++) {
            //loop that checks each character of password
            if (Character.isDigit(password.charAt(i))) {
                digit = true;// once it finds a digit set boolean to true
            }
            if (Character.isLetter(password.charAt(i))) {
                letter = true;  // once it finds a letter set boolean to true
            }
            if (Character.isWhitespace(password.charAt(i))) {
                spaces = false;  // if loop finds a space it sets boolean as false
            }
            if (password.endsWith("?") || password.startsWith("?")
                    || // if password starts or ends with ? or ! then true
                    password.endsWith("!") || password.startsWith("!")) {
                exclamation = false;// once it finds a symbol sets to true
            }
            for (int n = 0; (n < symbols.length); n++) { // iterate through character array until it finds a matching symbol
                if (password.contains(symbols[n])) {// when it finds a matching symbol = true
                    nonnumeric = true;
                } // end if
            }

            for (int a = 0; a < characters.length - 2; a++) {
// iterate trough the array containg the characters of the password. becasue we only care about three repeating charcaters we stop loop when a < characters.length-2 
                if (characters[a].equals(characters[a + 1]) && characters[a + 1].equals(characters[a + 2])) {
                    repeating = false; // if loop finds three repeating characters then set to false
                }
            }

        }
        if (!digit) {
            System.out.println("the password entered does not contain at least one number digit!");
        }
        if (!letter) {
            System.out.println("the password entered does not contain at least one letter character!");
        }
        if (!spaces) {
            System.out.println("the password entered should not contain any spaces!");
        }
        if (!exclamation) {
            System.out.println("the password entered should not begin or end with a ? or !");
        }
        if (!nonnumeric) {
            System.out.println("the password entered should contain one non alpha-numeric character!");
        }
        if (!repeating) {
            System.out.println("the password entered should not contain three or more repeating characters!");
        }
        return (length && digit && letter && spaces && exclamation && nonnumeric && repeating);
        /* return all boolean vairables to main if any one is false then value returned is false
        if all true then password is correct and value returned is true
         */
    }

    //************************************************************************************************
    public static String confirmPassword(String Password1) // method for confirming password. with first password passed as argument
    {
        String password; // declare password variable to confirm
        Scanner input = new Scanner(System.in);
        System.out.println("please re-enter the password to confirm :  ");
        password = input.nextLine();
        if (password.matches(Password1)) {
            System.out.println("checking that entries match...");
            System.out.println("entries match.");
        } else {
            System.out.println("checking that entries match...");
            System.out.println("Entries do not match, please try again!");
        }
        return password;
    }
//**************************************************************************************

}

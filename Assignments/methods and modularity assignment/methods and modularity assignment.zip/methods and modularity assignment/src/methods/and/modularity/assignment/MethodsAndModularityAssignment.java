/*methods and modularity.java
*Console I/O dialog for calculating average score from judges in gym competition
*for CSCI 111 
*last edited october 10th  5:09pm
@author Abraham Schultz
 */
package methods.and.modularity.assignment;

import java.util.Scanner;

public class MethodsAndModularityAssignment {

    /**
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Main method inputs score from judges and returns to total score value

// declare variables
        double score1, score2, score3, score4, score5, score6;
        int counter = 1;
// begin loop that asks for input until 6 differnt judges input has been given.
        do {
            score1 = inscore("Judge", counter);
            counter++;
            score2 = inscore("Judge", counter);
            counter++;
            score3 = inscore("Judge", counter);
            counter++;
            score4 = inscore("Judge", counter);
            counter++;
            score5 = inscore("Judge", counter);
            counter++;
            score6 = inscore("Judge", counter);
            counter++;

            /*1. calls a method asking for the score from a single judge,
     The method prints the judge number and score and return the judges score

             */
        } while (counter <= 6);
        //end loop

        double totalscore = score1 + score2 + score3 + score4 + score5 + score6;
        // adds the returned score to a total score

        double avgScore = getavg(totalscore, 6);// calls a method that finds average score from total score and prints it
      

//
    }
    //***********************************************************************************************
//Method gets average score and prints to console.
    public static double getavg(double totalscore, double numberjudges) {

        double avgScore;
        avgScore = totalscore / numberjudges;
        System.out.printf("%30s%8.2f%n", "The average score is:", avgScore);
        return avgScore;
    }
// judge1 score + judge2 score ..... judge 6 score / 6 = average score
    //***********************************************************************************************

    public static double inscore(String judge, int judgenumber) {
// method for getting score for each judge

        Scanner kb = new Scanner(System.in);
        //instance of scanner declared 
        // get score for judges double score = kb.nextDouble();
        System.out.print("Please enter the score on a scale of 1-10 for " + judge + " " + judgenumber + " : ");
        double score = kb.nextDouble();
        System.out.println("The score for " + judge + " " + judgenumber + " is " + score);
        return score;

    }
} //end main method

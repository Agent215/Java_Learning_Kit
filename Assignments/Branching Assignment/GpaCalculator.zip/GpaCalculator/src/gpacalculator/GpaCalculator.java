/*Gpa calculator
*Console I/O dialog for sorting Student GPA's 
*for CSCI 111 
*last edited september 26th 6:39pm
@author Abraham Schultz
 */
package gpacalculator;

import javax.swing.JOptionPane;

public class GpaCalculator {

    /**
     * Method determines the name and Graduation Status of Student
     * @param args the command line arguments
     */
    public static void main(String[] args) {

//Declare Variables
        String studentName;//student string name
        double Gpa ;//student double gpa
        String GpaString;// Gpa as string data type
        final double MAX_GPA = 4;//final double maxgpa = 4
        final double MIN_GPA = 0;//final double mingpa = 0

//Say hello to student and ask for name 
        studentName = JOptionPane.showInputDialog(null,"Hello welcome to the "
                + "student GPA calculator, please enter your name "
                + ": ","Name",JOptionPane.QUESTION_MESSAGE);

//ask for students gpa
        GpaString = JOptionPane.showInputDialog(null,"What is the GPA for " 
                + studentName + " : ","GPA",JOptionPane.QUESTION_MESSAGE);
        Gpa = Double.parseDouble(GpaString);// this changes the String in to a double data type

//calculate what students graduation status is, boolean
        
        if (Gpa > MAX_GPA || Gpa < MIN_GPA) {
            JOptionPane.showMessageDialog(null,"The number you entered is not "
                    + "a valid GPA " 
                ,"Graduation Status", 
                JOptionPane.ERROR_MESSAGE);// if gpa > 4 or gpa < 0 then statement for invalid gpa
        } else if (Gpa >= 3.8) {
            JOptionPane.showMessageDialog(null,"The GPA for " + studentName + 
                    " is " + Gpa + ". " + studentName + " will graduate Summa Cum Laude " 
                ,"Graduation Status", 
                JOptionPane.PLAIN_MESSAGE);
        }//if gpa >= 3.8 then statement for Summa cum laude
        else if (Gpa >= 3.6) {
             JOptionPane.showMessageDialog(null,"The GPA for " + studentName +
                     " is " + Gpa + ". " + studentName + " will graduate Magna Cum Laude " 
                ,"Graduation Status", 
                JOptionPane.PLAIN_MESSAGE);
        }//if gpa >= 3.6 then statement for Magna cum laude
        else if (Gpa >= 3.2) {
           JOptionPane.showMessageDialog(null,"The GPA for " + studentName + 
                   " is " + Gpa + ". " + studentName + " will graduate Cum Laude " 
                ,"Graduation Status", 
                JOptionPane.PLAIN_MESSAGE);
        } //if gpa >=3.2 then statement for cum laude
        else if (Gpa >= 2.0) {
            JOptionPane.showMessageDialog(null,"The GPA for " + studentName + 
                    " is " + Gpa + ". " + studentName + " will be elligible to graduate " 
                ,"Graduation Status", 
                JOptionPane.PLAIN_MESSAGE);
        }//if gpa >= 2.0then statement for between 2.0 and 3.2 students
        else if (Gpa < 2.0) {
            JOptionPane.showMessageDialog(null,"The GPA for " + studentName + 
                    " is " + Gpa + ". " + studentName + " will not be elligible to graduate " 
                ,"Graduation Status", 
                JOptionPane.WARNING_MESSAGE);
        }//if gpa < 2 then statement for not elligible to graduate students


    }// end main

}
 



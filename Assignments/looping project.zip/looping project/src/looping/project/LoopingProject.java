/*celsius fahrenheit table loop
*Console I/O dialog for creating celsius to fahrenhiet temperature table 
*for CSCI 111 
*last edited october 3rd  11:05am
@author Abraham Schultz
 */
package looping.project;

import java.util.Scanner;

public class LoopingProject {

    /**
     * @param args the command line arguments Method for displaying temperature
     * table of Celsius and Fahrenheit
     */
    public static void main(String[] args) {
        // public main method

// Declare variables
        String CityName;// cityname
        double CelsiusTemp;// temp in celsius
        double FahrenheitTemp;// temp in fahrenheit

        Scanner keyboard = new Scanner(System.in);// set up input stream from the keyboard

        System.out.print("Please enter a city name : ");
        CityName = keyboard.next();
//ask input for name of city

        System.out.print("Please enter temperature in Celsius : ");
        CelsiusTemp = keyboard.nextInt();
        // ask for input of temp in celsius

        double Maxtemp = CelsiusTemp + 40;// declare variable for max temp to print out
        System.out.printf("%12s%13s%12s%n", "Temperature:", "Celsius\u00b0 ", "Fahrenheit \u00b0");
        // print out table header
        while (CelsiusTemp <= Maxtemp) //  continue while temp in celsius  <= Maxtemp
        {

            FahrenheitTemp = CelsiusTemp * (9.0 / 5.0) + 32.0;
            // calculate celsius to fahrenheit
            System.out.printf("%20.0f%1s%12.1f%1s%n", CelsiusTemp, "\u00b0", FahrenheitTemp, "\u00b0");
            //print out celsius and fahrenheit in table format
            CelsiusTemp++;            //  increment +1 celsius

        }

//end loop
// end main method
    }

}

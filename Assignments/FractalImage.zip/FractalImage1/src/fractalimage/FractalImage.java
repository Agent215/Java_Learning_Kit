/*
*Application to draw a fractal square on a JFrame.
*for CSCI 112
*last edited January 31th 8:29pm
@author Abraham Schultz
 */
package fractalimage;

import javax.swing.*;

public class FractalImage {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//create new instance of a Fractal Square and set values
        FractalSquare Sierpinski = new FractalSquare();
        JFrame frame = new JFrame();
        frame.setTitle("Fractal Square");
        frame.setSize(1000,1000);
        frame.setLocation(300, 0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(Sierpinski);
        frame.setVisible(true);
    }// end main

}// end fractal image


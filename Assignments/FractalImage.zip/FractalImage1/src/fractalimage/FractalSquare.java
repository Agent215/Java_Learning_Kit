/*
*Class of object to draw a fractal square with randomly generated colors.
*for CSCI 112
*last edited January 31th 8:29pm
@author Abraham Schultz
 */
package fractalimage;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.Random;

class FractalSquare extends Canvas {

    public FractalSquare() {
    }// end FractalSquare Constructor
//*****************************************************************************
    //method to paint square

    @Override
    public void paint(Graphics g) {

        // size of starting square
        int width = 600;
        int height = 600;
        //location coordinates of starting square
        int Xco = width / 2;
        int Yco = height / 2;
        // a title for the image on the canvas
        g.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        String title = "Fractal Square";
        g.drawString(title, 150, 30);
        g.setColor(Color.black);// color of background square

        // paint first square
        g.fillRect(Xco, Yco, width, height);

        // call recursive method
        drawSquare(g, Xco, Yco, width);

    }//end paint
//******************************************************************************

    /*
    recursive method to draw fractal square
    takes x y coordinates and width of square as arguments
     */
    public void drawSquare(Graphics g, double Xco, double Yco, double width) {

        double length = width / 2; // side of new squares should be half of parent square
        double x1 = Xco + length; // location on x axis should be half way between the parent square
        double y1 = Yco + length;// location on y axis should be half way between parent square
        Random rand = new Random(); // new random number generator object to make random colors

        // rgb values to be generated randomly. i am  not using rgb as variable names because g is already being used as a variable.
        float roy = rand.nextFloat();
        float gee = rand.nextFloat();
        float biv = rand.nextFloat();

        Color randomColor = new Color(roy, gee, biv);

        if (length > 2) {
            // base of recursive algorithim is 2 pixels. This takes it through 8 levels of recursion

            //sets a random color each time through a branch of recursion
            g.setColor(randomColor);

            //fills a new top left sqaure
            g.fillRect((int) Xco, (int) Yco, (int) length, (int) length);

            // draws a new bottom left sqaure
            g.drawRect((int) Xco, (int) y1, (int) length, (int) length);

            //fills a new bottom right sqaure
            g.fillRect((int) x1, (int) y1, (int) length, (int) length);

            //draws a new top right sqaure 
            g.drawRect((int) x1, (int) Yco, (int) length, (int) length);

            //drawSquare method on bottom left square
            drawSquare(g, (int) Xco, (int) y1, (int) length);

            //drawSquare method on top right square
            drawSquare(g, (int) x1, (int) Yco, (int) length);

        }//end if
    }//end drawSqaure

}// ends FractalSquare

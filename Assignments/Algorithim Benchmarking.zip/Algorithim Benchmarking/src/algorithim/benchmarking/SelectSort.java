/*
 *SelectSort.java
 *@author Abraham Schultz
 *CSCI 112 
 *Spring 2017
 *last edited 3/02/2017 3:13pm
 class to call selction sorting method
*/
package algorithim.benchmarking;

/**
 *
 * @author c317
 */
public class SelectSort {

    //this method is a selction sort based method to sort a String array alphabeticly
    public static void doSelectSort(int[] a) {

        long start = System.currentTimeMillis();
        long end = start + 30 * 1000; // 20 seconds * 1000 ms/sec
        int pointer;// location in the array where we will insert the minimum from the remainder of the list 
        int minimum;//location of the minimum value in the remainder of the list 
        int temp; //  catalyst variable for String swapping

        //
        for (pointer = 0; pointer < a.length; pointer++) {

            // find the minimum value in the remainder of the list  minimum = pointer;
            minimum = pointer;
            // initialize the minimum to be the first value in the remainder of the list 
            //  do {
            // add inner for loop
            for (int i = pointer + 1; (i < a.length - 1); i++) {// i iterates from pointer to the end of the list – one pass

                if (a[i] < (a[minimum])) {

                    /* compares current value being pointed at with current minimum,
                    sets new minimum if pointer is less then minimum 
                     
                     */
                    minimum = i;
                    // location of the minimum so far for this pass through the remainder of the list 
                }// end if

            } // end for
            // } while (System.currentTimeMillis() < end);
            temp = a[pointer];
            a[pointer] = a[minimum];
            a[minimum] = temp;

            //swap  a[pointer] and a[minimum]; swap the value in pointer with this pass’s minimum
        }// end for
        // };
    }// end selectSort

    //********************************************************************************************
}//end class select sort

/*
 *InsertSort.java
 *@author Abraham Schultz
 *CSCI 112 
 *Spring 2017
 *last edited 3/01/2017 1:14pm
 class to call insert sorting method.
 */
package algorithim.benchmarking;

/**
 *
 * @author c317
 */
public class InsertSort {
    //this method is an insertion sort based method to sort a String array alphabeticly

    public static void doInsertSort(int[] a) {
        int temp; // catalyst variable for String swapping

        long start = System.currentTimeMillis();
        long end = start + 30 * 1000; // 30 seconds * 1000 ms/sec

        //
        //iterate through loop , int i is a pointer to an item in the unsorted list 
        for (int i = 1; i < a.length; i++) {
            //do {
            for (int j = i; j > 0; j--) { // inner loop to find where to insert new value
                // creates variable j which points to items in sorted list by iterating backwards.

                // once j is pointing at a word in the sorted list that should precede it then swap words.
                //this could be made its own method call swap
                if (a[j] < (a[j - 1])) {

                    temp = a[j];
                    a[j] = a[j - 1];
                    a[j - 1] = temp;// this swaps list items 
                }// end if
            }//end for
            // } while (System.currentTimeMillis() < end);
        }//end for
        // 
    }// end insertSort
//*******************************************************************
}

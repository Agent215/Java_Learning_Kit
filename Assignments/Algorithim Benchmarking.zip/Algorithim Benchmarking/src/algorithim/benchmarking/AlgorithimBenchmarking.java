/*AlgorithimBenchmarking.java
 *@author Abraham Schultz
 *CSCI 112 
 *Spring 2017
 *last edited 3/03/2017 1:14pm
 * Program That benchmarks the speed in seconds for four diffenert sorting algorithims:
 * insertion sort, selection sort, bubble sort and merge sort.
 * this program tests the time it takes for each algorithim with 6 differnt sized data sets and resets the array
 * inbetween sorts.  The mergeSort, merge and writeLines methods
 *were provided by the professor.
 */
package algorithim.benchmarking;

/**
 *
 * @author c317
 */
public class AlgorithimBenchmarking {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {

        // int values for diffent sizes of arrays to be sorted
        int tenK = 10000;
        int twentyK = 20000;
        int oneHundredK = 100000;
        int twoHundredK = 200000;
        int oneMillion = 1000000;
        int twoMillion = 2000000;

        int[] original = new int[twoMillion];
        for (int i = 0; i < twoMillion; i++) { // creates the original array and populates it with 2 million random numbers
            original[i] = (int) (Math.random() * 100000 + 1); // numbers randomly generated bewtwen 1 and 100,000
        }//end for 

        Manager manager = new Manager();

        // this loop tests each of the four sorting methods on 6 differnet size data sets. 
        //within the sortEachSize method is an additional loop which tests each algorithim 100 times
        //as is this program will take a very long time to run there is no time out mechanisim, alter the variable i to select sorting method.
        // i is the variable to switch sorting methods. 
        //1 = bubble, 2= select, 3=insert , 4= merge
        for (int i = 1; i < 5; i++) {
            writeLines(original, "beforeSort.txt");
            manager.sortEachSize(original, i, tenK);
            manager.sortEachSize(original, i, twentyK);
            manager.sortEachSize(original, i, oneHundredK);
            manager.sortEachSize(original, i, twoHundredK);
            manager.sortEachSize(original, i, oneMillion);
            manager.sortEachSize(original, i, twoMillion);
        }// end for
    }// end main

    // *************************************************************

    /* This method writes an int array to a text data file.  
     * The first parameter is the array. The second parameter
     * is the file name.
     */
    public static void writeLines(int[] a, String fileName) throws Exception {
        // create a File class object with the given file name
        java.io.File out = new java.io.File(fileName);
        // Create a PrintWriter output stream and link it to the File object
        java.io.PrintWriter outfile = new java.io.PrintWriter(out);

        // write the elements of an int array, separated by spaces
        for (int i = 0; i < a.length; i++) {
            outfile.print(a[i] + " ");
        }

        // print a newline at the end of the list of integers
        outfile.println();

        outfile.close();

    } // end writeLines

    /**
     * **********************************************
     */
}//end class AlgorthimBenchmarking

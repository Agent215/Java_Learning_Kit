/*
 *Manager.java
 *@author Abraham Schultz
 *CSCI 112 
 *Spring 2017
 *last edited 3/01/2017 1:14pm
 class to call a method which depending on variable passed through will run one of 
 four possible sorting methods. No time out mechanisim exists yet.
 */
package algorithim.benchmarking;

import static algorithim.benchmarking.AlgorithimBenchmarking.writeLines;

/**
 *
 * @author c317
 */
public class Manager {

    // this method controls which sorting method is called using a switch
    double sortEachSize(int[] original, int sortType, int size) throws Exception {
        int[] a = new int[size]; // temporary array to hold copy of original array
        String fileName = null;// to create a file associted with that search method
        switch (sortType) {
            case 1:;//bubble                    
                System.out.printf("bubble sort, data size:%d\n", size);
                fileName = "bubbleSorted.txt";
                break;
            case 2:;//selection;
                System.out.printf("select sort, data size:%d\n", size);
                fileName = "selectSorted.txt";
                break;
            case 3:;//insert
                System.out.printf("insert sort, data size:%d\n", size);
                fileName = "insertSorted.txt";
                break;
            case 4:;// merge
                System.out.printf("merge sort, data size:%d\n", size);
                fileName = "mergreSorted.txt";
                break;// 

        }// end switch

        // this loop takes eacch sorting method through 100 cycles
        for (int k = 0; k < 100; k++) {//100 at 30 to test

            // wrap the whole sorting code in a timing loop to terminate if algorthim takes more then 30 seconds
            long start = System.currentTimeMillis();
            long end = start + 30 * 1000; // 30 seconds * 1000 ms/sec
            int i = 0; // loop counter
            //while (System.currentTimeMillis() < end && i < 20) {

                for (i = 0; i < size; i++) {
                    a[i] = original[i];
                    // this loops copy the apropriate amount of items the from  original array, 
                    //based on size of array. this makes sure the array is reset between each run
                }//end for

                long startTime = System.nanoTime();// starts mesuring speed of algortithim
                switch (sortType) {
                    case 1:;//bubble

                        BubbleSort.doBubbleSort(a);
                        break;
                    case 2:;//selection;
                        SelectSort.doSelectSort(a);
                        break;
                    case 3:;//insert
                        InsertSort.doInsertSort(a);
                        break;
                    case 4:;// merge
                        MergeSort.doMergeSort(original, a, 0, (a.length - 1));
                        break;// merge

                }// end switch

                long endTime = System.nanoTime();
                long duration = endTime - startTime;
                double totalTime = (double) duration / 1000000000;
                if (System.currentTimeMillis() >= end) {

                    System.out.println("Algorthim Timed Out");

                } else {
                    System.out.printf("\t %12.8f \n", totalTime);
                }
           // }// while
            if (System.currentTimeMillis() >= end) {

                break;
            }// end if
        }// end for

        writeLines(a, fileName); // creates a file with the sorted array to test 
        return 0.0;
    }// end sortEachSize
}// end class manager

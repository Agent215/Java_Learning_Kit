/*
 *BubbleSort.java
 *@author Abraham Schultz
 *CSCI 112 
 *Spring 2017
 *last edited 3/02/2017 9:24pm
 class to call BubbleSort  method.
time out mechanisim does exist in the boolean statment at the end of the while.
after 30 seconds it ends.
 */
package algorithim.benchmarking;

/**
 *
 * @author c317
 */
public class BubbleSort {

    // * ***********************************************************************
    /* This method sorts an array of Strings line by line 
     * using a simple bubble sort. 
     * 
     * The first parameter refers to the array in the main method.  
     * The second parameter is the number of elements in the array that 
     * actually contain data
     */
    public static void doBubbleSort(int[] a) {

        long start = System.currentTimeMillis();
        long end = start + 30 * 1000; // 30 seconds * 1000 ms/sec

        boolean swapped;    //  keeps track of when array values are swapped 
        int i;              // a loop counter
        int temp;         // catalyst variable for String swapping

        // Each iteration of the outer do loop is is one pass through the loop. 
        // If anything was swapped, it makes another pass
        do {
            // set swapped to false before each pass
            swapped = false;

            // the for loop is a pass through the array to the second to last element
            for (i = 0; (i < a.length - 1); i++) {
                // if the two items are out of order  see page 16 for String compareTo() 
                if (a[i + 1] < (a[i])) {
                    // swap the two items ans set swapped to true    
                    temp = a[i];
                    a[i] = a[i + 1];
                    a[i + 1] = temp;

                    swapped = true;

                }  // end if
            } // end for

            // the outer loop will repeat if a swap was made  – another passs
        } while (swapped && System.currentTimeMillis() < end);// times out at 30 seconds

        if (System.currentTimeMillis() >= end) {

        }

    } // end dobubbleSort
//********************************************************************************

}//end class bubble sort

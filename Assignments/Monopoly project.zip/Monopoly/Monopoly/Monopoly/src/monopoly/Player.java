/*
 Monopoly plaer class
*Class for a player object in monopoly
*for CSCI 111 
*last edited november 17h 1:39pm
@author Abraham Schultz
 */
package monopoly;

import java.util.Random;
import java.util.Scanner;

public class Player {

    static boolean toString;

    // list of attributes of player class
    private String name; //name of player 
    private String token; // token player is using
    private int location; // location of token on board
    private int balance; // how much money player has

    // CONSTRUCTORS 
    public Player() {
        name = "";
        token = "";
        location = 0;
        balance = 1500;
    }// end player

    public Player(String name, String token, int location, int balance) {
        this.name = name;
        this.token = token;
        this.location = location;
        this.balance = balance;
    } // end player(args)

    //ACCESSORS 
    public String getName() {
        return name;
    } //end get name

    public String getToken() {
        return token;
    }//end get token

    public int getLocation() {
        return location;
    }//end get location

    public int getBalance() {
        return balance;
    }//end get balance

    //MUTATORS
    public void setName() {// code which asks for player name
        String name;
        Scanner inputName = new Scanner(System.in);// instance of scanner
        System.out.println("Please enter the name of this player");
        name = inputName.nextLine();
        System.out.println("hello " + name);
        this.name = name;

    }// end set name

    public void setToken() {
// code which asks user to pick a token    iron, race car, thimble, shoe, top hat, battleship,The Scottie dog, wheelbarrow
        String token = "";
        int tokenChoice;

        Scanner inputToken = new Scanner(System.in);//instance of scanner
        System.out.printf("please choose a token by entering the number that is next to the token of your choice.");
        System.out.printf("%n%5s%n%5s%n%5s%n%9s%n%9s%n%15s%n%15s%n%15s%n", " 1 = "
                + "Iron", " 2 = Race Car", " 3 = Thimble", "4 = Shoe", " 5 = Top Hat", " 6 = Battleship", " 7 = Scottie dog", " 8 = Wheelbarrow");

        do {//loop that continues until user enters a number bewtween 1-8
            System.out.println("please enter a number bewtween 1-8");
            tokenChoice = inputToken.nextInt();
        } while (tokenChoice <= 0 || tokenChoice >= 9);
        if (tokenChoice == 1) {
            System.out.println("you have selected the Iron as your token");
            token = "Iron";
        }
        if (tokenChoice == 2) {
            System.out.println("you have selected the Race Car as your token");
            token = "Race Car";
        }
        if (tokenChoice == 3) {
            System.out.println("you have selected the Thimble as your token");
            token = "Thimble";
        }
        if (tokenChoice == 4) {
            System.out.println("you have selected the Shoe as your token");
            token = "Shoe";
        }
        if (tokenChoice == 5) {
            System.out.println("you have selected the Top Hat as your token");
            token = "Top Hat";
        }
        if (tokenChoice == 6) {
            System.out.println("you have selected the Battleship as your token");
            token = "Battleship";
        }
        if (tokenChoice == 7) {
            System.out.println("you have selected the Scottie Dog as your token");
            token = "Scottie Dog";
        }
        if (tokenChoice == 8) {
            System.out.println("you have selected the Wheelbarrow as your token");
            token = "Wheelbarrow";
        }

        this.token = token;

    }// end set token

    public void setLocation(int currentLocation) {// code which rolls dice and sets location on board
        // variables

        int newLocation;
        int totalRoll;
        int die1;
        int die2;
        Random random = new Random();// instance of random number generator
        die1 = random.nextInt(6) + 1;// finds a number between 0-5, so we +1 to get 1-6
        System.out.println("die#1 rolled a " + die1);
        die2 = random.nextInt(6) + 1;
        System.out.println("die#2 rolled a " + die2);
        totalRoll = die1 + die2;
        newLocation = totalRoll + currentLocation;
        System.out.println("your total roll is: " + totalRoll);
        if (newLocation > 39) {
            newLocation = newLocation - 40;
        }
        this.location = newLocation;

    }// end set location

    public void setBalance(int rent) {// code which subtracts rent from total balance
        int currentBalance = this.balance;

        int newBalance = currentBalance - rent;
        System.out.println("your new bank balance is: " + newBalance + "$");
        this.balance = newBalance;

    }// end set balance

    public String toString() {// to string method
        String info;
        info = ("the players name is " + name + ", the players token is " + token
                + ", the players board location is " + location + ", the players bank balance is " + balance);
        return info;
    }// end to string

    /*
    attributes
    
    - name: String
 - token: String
 - location: int
 - balance: int
  ***************************************************************************************************
    methods
    
+ Player(): void                                    
+ Player(String, String, int, int): void 
+ getName(): String
 + getToken(): String
 + getLocation() int 
+ getBalance() int 
+ setName(String): void 
+ setToken(String): void 
+ setLocation(int): void 
+ setBalance(int): void 
+ toString:() String (name, token, location

     */
}

/* Monopoly.java
 * 
 * CSCI 111 Fall 2013 
 * last edited November 2, 2013 by C. Herbert
 * 
 * This package contains code that can be used as the basis of a monopoly game
 * It has a class of BoardSquares for the board squares in a Monopoly game,
 * and a main program that puts the squares into an array.
 * 
 * The main method has code to test the program by printing the data from the array
 * 
 * This is for teaching purposes only. 
 * Monopoly and the names and images used in Monopoly are 
 * registered trademarks of Parker Brothers, Hasbro, and others.
 */
package monopoly;

import java.util.*;
import java.util.Scanner;

/**
 *
 * @author cherbert
 */
public class Monopoly {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {

        BoardSquare[] square = new BoardSquare[40]; // array of 40 monopoly squares
        Player player1 = new Player();// instance of player class is created
        int currentSquare = player1.getLocation(); // intialized at 0
        int newSquare; // variable to hold value of newsquare that player lands on
        loadArray(square);
        player1.setName();// method asks for players name
        player1.setToken();// method ask for player to choose token
        System.out.println(player1.getName() + " is at the " + square[currentSquare].getName() + " square"); // prints out starting location
        do {

            promptEnterKey(); // method to hit enter to continue
            System.out.println("Players current bank balance is: " + player1.getBalance() + "$");// displays players balance before each turn
            player1.setLocation(player1.getLocation()); // method rolls dice
            newSquare = player1.getLocation();
            System.out.println(player1.getName() + "'s " + player1.getToken() + " has landed on " + square[newSquare].getName()); // tells user where they are

            if (square[newSquare].getRent() > 0) { 

                System.out.println(" the rent is " + square[newSquare].getRent() + "$");

            } // if there is a rent , tell the user

            player1.setBalance(square[newSquare].getRent());
            /*
            System.out.println(newSquare);//test
            System.out.println(currentSquare);//test
             */
        } while (player1.getBalance() > 0);
        System.out.println("you have gone bankrupt!!!");

    } // main()
    //***********************************************************************

    // method to load the BoardSquare array from a data file
    public static void loadArray(BoardSquare[] square) throws Exception {
        int i; // a loop counter

        // declare temporary variables to hold BoardSquare properties read from a file
        String inName;
        String inType;
        int inPrice;
        int inRent;
        String inColor;

        // Create a File class object linked to the name of the file to be read
        java.io.File squareFile = new java.io.File("squares.txt");

        // Create a Scanner named infile to read the input stream from the file
        Scanner infile = new Scanner(squareFile);

        /* This loop reads data into the square array.
         * Each item of data is a separate line in the file.
         * There are 40 sets of data for the 40 squares.
         */
        for (i = 0; i < 40; i++) {
            // read data from the file into temporary variables
            // read Strings directly; parse integers
            inName = infile.nextLine();
            inType = infile.nextLine();
            inPrice = Integer.parseInt(infile.nextLine());
            inRent = Integer.parseInt(infile.nextLine());
            inColor = infile.nextLine();

            // intialze each square with the BoardSquare constructor
            square[i] = new BoardSquare(inName, inType, inPrice, inRent, inColor);
        } // end for
        infile.close();

    } // endLoadArray
    //***********************************************************************

    public static void promptEnterKey() {// method for hitting enter key to continue
        System.out.println("Press \"ENTER\" to roll dice");
        Scanner scanner = new Scanner(System.in); //scanner delcared
        scanner.nextLine();
    }
} // end class Monopoly
//***************************************************************************


/* code for a class of Monopoly squares
 * 
 * CSCI 111 Fall 2013 
 * last edited November 2, 2013 by C. Herbert
 * Each object in this class is a square for the board game Monopoly.
 * 
 * This is for teaching purposes only. 
 * Monopoly and the names and images in the game are 
 * registered trademarks of Parker Brothers, Hasbro, and others.
 */

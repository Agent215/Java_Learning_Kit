/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testsqr;

/**
 *
 * @author Chuck
 */
public class Testsqr {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double x = 100.0;
        double sroot; 
                
        sroot = Math.sqrt(x);
             
        System.out.println("sqrt of x = "+ sroot);
    }
}
